package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Day0321Application {

    public static void main(String[] args) {
        SpringApplication.run(Day0321Application.class, args);
    }

}
