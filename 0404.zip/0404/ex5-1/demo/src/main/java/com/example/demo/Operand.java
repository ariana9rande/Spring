package com.example.demo;

import org.springframework.stereotype.Component;

public class Operand
{
    int value;
    public int getValue()
    {
        return value;
    }
    public void setValue(int v)
    {
        value = v;
    }
}
