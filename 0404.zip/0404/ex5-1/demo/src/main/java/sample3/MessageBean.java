package sample3;

public interface MessageBean
{
    void sayHello(String name);
}
