package sample1;

public interface MessageBean
{
    void sayHello();
}