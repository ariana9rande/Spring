package com.hjh.test.repository;

import com.hjh.test.model.Employee;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface EmployeeRepository extends JpaRepository<Employee, Long>
{
    Employee findEmployeeById(Long id);

    List<Employee> findAllByOrderByNameAsc();

    Employee findEmployeeByPhoneNumber(String phoneNumber);

    Employee findEmployeeByEmail(String email);

    @Query("SELECT e FROM Employee e WHERE " +
            "(:id IS NULL OR e.id = :id) AND " +
            "(:position IS NULL OR e.position = :position) AND " +
            "(:name IS NULL OR e.name LIKE %:name%) AND " +
            "(:phoneNumber IS NULL OR e.phoneNumber LIKE %:phoneNumber%) AND " +
            "(:email IS NULL OR e.email LIKE %:email%) " +
            "ORDER BY e.name ASC")
    List<Employee> searchEmployees(Long id, String position, String name, String phoneNumber, String email);
}
