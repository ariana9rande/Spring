package com.hjh.test.service;

import com.hjh.test.model.Employee;
import com.hjh.test.repository.EmployeeRepository;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.stereotype.Service;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.List;
import java.util.StringJoiner;

@Service
public class EmployeeService
{
    private final EmployeeRepository employeeRepository;

    public EmployeeService(EmployeeRepository employeeRepository)
    {
        this.employeeRepository = employeeRepository;
    }

    public Employee findEmployeeById(Long id)
    {
        return employeeRepository.findEmployeeById(id);
    }

    public void register(Employee employee)
    {
        Employee newEmployee = new Employee();
        newEmployee.setPosition(employee.getPosition());
        newEmployee.setName(employee.getName());
        newEmployee.setPhoneNumber(employee.getPhoneNumber());
        newEmployee.setEmail(employee.getEmail());

        employeeRepository.save(newEmployee);
    }

    public List<Employee> getAllEmployeesOrderByNameAsc()
    {
        return employeeRepository.findAllByOrderByNameAsc();
    }

    public Employee findEmployeeByPhoneNumber(String phoneNumber)
    {
        return employeeRepository.findEmployeeByPhoneNumber(phoneNumber);
    }

    public Employee findEmployeeByEmail(String email)
    {
        return employeeRepository.findEmployeeByEmail(email);
    }

    public void editEmployee(Employee employee)
    {
        employeeRepository.save(employee);
    }

    public void deleteEmployee(Employee employee)
    {
        employeeRepository.delete(employee);
    }

    public List<Employee> searchEmployees(Long id, String position, String name, String phoneNumber, String email)
    {
        // 비어 있는 필드는 검색 조건에서 빠지도록
        return employeeRepository.searchEmployees((id != null && id > 0) ? id : null,
                (position != null && !position.isEmpty()) ? position : null,
                (name != null && !name.isEmpty()) ? name : null,
                (phoneNumber != null && !phoneNumber.isEmpty()) ? phoneNumber : null,
                (email != null && !email.isEmpty()) ? email : null);
    }

    public String generateCSV()
    {
        List<Employee> employees = employeeRepository.findAll();

        StringBuilder csvData = new StringBuilder();

        csvData.append("직원번호,직급,이름,전화번호,이메일\n");

        for (Employee employee : employees)
        {
            StringJoiner joiner = new StringJoiner(",");
            joiner.add(String.valueOf(employee.getId()));
            joiner.add(employee.getPosition());
            joiner.add(employee.getName());
            joiner.add(employee.getPhoneNumber());
            joiner.add(employee.getEmail());

            csvData.append(joiner.toString()).append("\n");
        }

        return csvData.toString();
    }

    public byte[] generateXLS() throws IOException
    {
        List<Employee> employees = employeeRepository.findAllByOrderByNameAsc();

        try (Workbook workbook = new HSSFWorkbook())
        {
            return generateWorkbook(employees, workbook);
        }
    }

    public byte[] generateXLSX() throws IOException
    {
        List<Employee> employees = employeeRepository.findAllByOrderByNameAsc();

        try (Workbook workbook = new XSSFWorkbook())
        {
            return generateWorkbook(employees, workbook);
        }
    }

    private byte[] generateWorkbook(List<Employee> employees, Workbook workbook) throws IOException
    {
        Sheet sheet = workbook.createSheet("Employee List");

        Row headerRow = sheet.createRow(0);
        headerRow.createCell(0).setCellValue("Employee ID");
        headerRow.createCell(1).setCellValue("Position");
        headerRow.createCell(2).setCellValue("Name");
        headerRow.createCell(3).setCellValue("Phone Number");
        headerRow.createCell(4).setCellValue("Email");

        int rowNum = 1;
        for (Employee employee : employees)
        {
            Row row = sheet.createRow(rowNum++);
            row.createCell(0).setCellValue(employee.getId());
            row.createCell(1).setCellValue(employee.getPosition());
            row.createCell(2).setCellValue(employee.getName());
            row.createCell(3).setCellValue(employee.getPhoneNumber());
            row.createCell(4).setCellValue(employee.getEmail());
        }

        try (ByteArrayOutputStream outputStream = new ByteArrayOutputStream())
        {
            workbook.write(outputStream);
            return outputStream.toByteArray();
        }
    }
}
