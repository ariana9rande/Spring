package com.hjh.test.controller;

import com.hjh.test.model.Employee;
import com.hjh.test.service.EmployeeService;
import org.apache.poi.ss.usermodel.Workbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.io.IOException;
import java.util.List;

@Controller
@RequestMapping("/employee")
public class EmployeeController
{
    private final EmployeeService employeeService;

    public EmployeeController(EmployeeService employeeService)
    {
        this.employeeService = employeeService;
    }

    @GetMapping("/register")
    public String showRegister()
    {
        return "employee/register";
    }

    @PostMapping("/register")
    public String processRegister(Model model,
//                                  @RequestParam(value = "id") Long id,
                                  @RequestParam(value = "position") String position,
                                  @RequestParam(value = "name") String name,
                                  @RequestParam(value = "phoneNumber") String phoneNumber,
                                  @RequestParam(value = "email") String email)
    {
//        if(employeeService.findEmployeeById(id) != null)
//        {
//            model.addAttribute("message", "이미 존재하는 직원번호입니다.");
//            return "employee/register";
//        }

        Employee employee = new Employee();
//        employee.setId(id);
        employee.setPosition(position);
        employee.setName(name);
        employee.setPhoneNumber(phoneNumber);
        employee.setEmail(email);

        employeeService.register(employee);
        model.addAttribute("employee", employee);

        return "employee/registerSuccess";
    }

    @GetMapping("/list")
    public String showEmployeeList(Model model)
    {
        model.addAttribute("employeeList", employeeService.getAllEmployeesOrderByNameAsc());
//        for (Employee e : employeeService.getAllEmployeesOrderByNameAsc())
//        {
//            System.out.println("name: " + e.getName());
//        }
        return "employee/list";
    }

    @GetMapping("/edit/{id}")
    public String showEditForm(@PathVariable Long id,
                               Model model)
    {
        Employee employee = employeeService.findEmployeeById(id);
        model.addAttribute("employee", employee);

        return "employee/edit";
    }

    @PostMapping("/edit")
    public String editProfile(@RequestParam("previousId") Long previousId,
                              @RequestParam("previousPhoneNumber") String previousPhoneNumber,
                              @RequestParam("previousEmail") String previousEmail,
                              @RequestParam("id") Long id,
                              @RequestParam("position") String position,
                              @RequestParam("name") String name,
                              @RequestParam("phoneNumber") String phoneNumber,
                              @RequestParam("email") String email,
                              Model model)
    {
        // 직원번호를 변경했을 경우
        if (id != previousId)
        {
            // 변경된 직원번호가 중복된 경우
            if (employeeService.findEmployeeById(id) != null)
            {
                model.addAttribute("employee", employeeService.findEmployeeById(previousId));
                model.addAttribute("message", "사용중인 직원번호입니다.");
                return "employee/editFailed";
            }
        }

        Employee employee = employeeService.findEmployeeById(previousId);
        employee.setPosition(position);
        employee.setName(name);

        // 전화번호를 변경했을 경우
        if (!phoneNumber.equals(previousPhoneNumber))
        {
            // 변경된 전화번호가 중복된 경우
            if (employeeService.findEmployeeByPhoneNumber(phoneNumber) != null)
            {
                model.addAttribute("employee", employeeService.findEmployeeById(previousId));
                model.addAttribute("message", "사용중인 전화번호입니다.");
                return "employee/editFailed";
            }
        }
        employee.setPhoneNumber(phoneNumber);

        // 이메일을 변경했을 경우
        if (!email.equals(previousEmail))
        {
            // 변경된 이메일이 중복된 경우
            if (employeeService.findEmployeeByEmail(email) != null)
            {
                model.addAttribute("employee", employeeService.findEmployeeById(previousId));
                model.addAttribute("message", "사용중인 이메일입니다.");
                return "employee/editFailed";
            }
        }
        employee.setEmail(email);

        employeeService.editEmployee(employee);

        model.addAttribute("employee", employeeService.findEmployeeById(previousId));
        return "employee/editSuccess";
    }

    @PostMapping("/delete/{id}")
    public String deleteEmployee(@PathVariable("id") Long id,
                                 Model model)
    {
        Employee employee = employeeService.findEmployeeById(id);

        employeeService.deleteEmployee(employee);

        model.addAttribute("employee", employee);
        return "employee/deleteSuccess";
    }

    @GetMapping("/search")
    public String searchEmployee(@RequestParam(value = "id", required = false) Long id,
                                 @RequestParam(value = "position", required = false) String position,
                                 @RequestParam(value = "name", required = false) String name,
                                 @RequestParam(value = "phoneNumber", required = false) String phoneNumber,
                                 @RequestParam(value = "email", required = false) String email,
                                 Model model)
    {
        List<Employee> searchResult = employeeService.searchEmployees(id, position, name, phoneNumber, email);

        model.addAttribute("employeeList", searchResult);
        return "employee/list";
    }

    @GetMapping("/employee/downloadEmployeeList/CSV")
    public ResponseEntity<byte[]> downloadEmployeeListToCSV() throws IOException
    {

        byte[] csvData = employeeService.generateCSV().getBytes();
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.parseMediaType("text/csv"));
        headers.setContentDispositionFormData("attachment", "employee_list.csv");
        headers.setContentLength(csvData.length);

        return new ResponseEntity<>(csvData, headers, org.springframework.http.HttpStatus.OK);
    }

    @GetMapping("/employee/downloadEmployeeList/XLS")
    public ResponseEntity<byte[]> downloadEmployeeListToXLS() throws IOException
    {
        byte[] xlsData = employeeService.generateXLS();
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.parseMediaType("application/vnd.ms-excel"));
        headers.setContentDispositionFormData("attachment", "employee_list.xls");
        headers.setContentLength(xlsData.length);

        return new ResponseEntity<>(xlsData, headers, org.springframework.http.HttpStatus.OK);
    }

    @GetMapping("/employee/downloadEmployeeList/XLSX")
    public ResponseEntity<byte[]> downloadEmployeeListToXLSX() throws IOException
    {
        byte[] xlsxData = employeeService.generateXLSX();
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(
                MediaType.parseMediaType("application/vnd.malformations-office document.spreadsheet.sheet"));
        headers.setContentDispositionFormData("attachment", "employee_list.xlsx");
        headers.setContentLength(xlsxData.length);

        return new ResponseEntity<>(xlsxData, headers, org.springframework.http.HttpStatus.OK);
    }
}
